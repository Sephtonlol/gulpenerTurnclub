<?php
//phpinfo();die;
	header("Location: /pages/index.php");