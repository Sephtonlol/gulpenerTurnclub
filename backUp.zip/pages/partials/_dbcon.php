<?php

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$mysqli = new mysqli("localhost", "hyvbU6-zadqux-pigbud", "hyvbU6-zadqux-pigbud", "gulpenerturnclub_nl_");

$connect=mysqli_connect("localhost","hyvbU6-zadqux-pigbud","hyvbU6-zadqux-pigbud","gulpenerturnclub_nl_") or die(mysqli_error($connect));